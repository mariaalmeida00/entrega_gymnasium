from setuptools import setup

setup(
    name="gymnasium_csv",
    version="0.0.1",
    install_requires=["gymnasium>=0.26.3", "pygame>=2.1.0"],
    packages=["gymnasium_csv"],
)
